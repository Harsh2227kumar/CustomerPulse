"""CustomerPulse backend application package."""
