"""Shared backend utility helpers."""
