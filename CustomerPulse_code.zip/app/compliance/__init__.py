"""Deterministic banking compliance engine."""
