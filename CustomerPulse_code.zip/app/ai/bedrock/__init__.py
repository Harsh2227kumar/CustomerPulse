"""Amazon Bedrock Claude integration."""
