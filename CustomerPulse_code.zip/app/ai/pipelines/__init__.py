"""Composable AI processing pipelines."""
