"""AI output validation guards."""
