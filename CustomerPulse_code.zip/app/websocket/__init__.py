"""WebSocket connection management."""
